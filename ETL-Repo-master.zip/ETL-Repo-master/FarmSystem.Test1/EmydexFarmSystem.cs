﻿using System;
using System.Collections.Generic;

namespace FarmSystem.Test1 
{
    public class EmydexFarmSystem 
    {

        //TEST 1
        List<object> animals = new List<object>();
        public void Enter(object animal)
        {
            //TODO Modify the code so that we can display the type of animal (cow, sheep etc) 
            //Hold all the animals so it is available for future activities
            //Console.WriteLine("Animal has entered the Emydex farm");
            Console.WriteLine(animal + " has entered the Emydex farm");
            animals.Add(animal);
        }
     
        //TEST 2
        public void MakeNoise()
        {
            //Test 2 : Modify this method to make the animals talk
            //Console.WriteLine("There are no animals in the farm");
            Cow cow = new Cow();
            cow.Talk();
            Hen hen = new Hen ();
            hen.Talk();
            Horse horse = new Horse();
            horse.Talk();
            Sheep sheep = new Sheep();
            sheep.Talk();

           
        }

        //TEST 3
        public void MilkAnimals()
        {
            //Console.WriteLine("Cannot identify the farm animals which can be milked");
            Cow cow = new Cow();
            cow.ProduceMilk();
        }

        //TEST 4
        public void ReleaseAllAnimals()
        {
           //Console.WriteLine("There are still animals in the farm, farm is not free");
            foreach (object animal in animals)
            {
                Console.WriteLine(animal + " has left the farm");
            }
        }

        public void FarmEmpty()
        {
            animals.Clear();
            Console.WriteLine("Emydex Farm is now empty");
        }
    }
}